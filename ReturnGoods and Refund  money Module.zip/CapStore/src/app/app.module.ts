import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {MatRadioModule, MatFormFieldModule, MatInputModule} from '@angular/material'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ReturngoodsComponent } from './returngoods/returngoods.component';
import { ReturnpageComponent } from './returnpage/returnpage.component';

import { RefundComponent } from './refund/refund.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'
import { HttpClientModule } from '@angular/common/http';
import { ReturnmessageComponent } from './returnmessage/returnmessage.component';

@NgModule({
  declarations: [
    AppComponent,
    ReturngoodsComponent,
    ReturnpageComponent,
    RefundComponent,
    ReturnmessageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatRadioModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    FormsModule,
    BrowserAnimationsModule,
    MatInputModule,
    HttpClientModule
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
