export class inventory {
    inventoryId: number;
    productId: number;
    merchantId: number;

    productDescription: string
    productActualPrice: string
    productDiscountPrice: string
    productQuantity: string
}