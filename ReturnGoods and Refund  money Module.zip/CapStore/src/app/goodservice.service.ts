import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { inventory } from './model/inventory';
@Injectable({
  providedIn: 'root'
})
export class GoodserviceService {

  constructor(private http: HttpClient) { }
  baseurl : "http://localhost:8880";


  getAll(){
return this.http.get<inventory[]>(this.baseurl +"/all");

  }
}
