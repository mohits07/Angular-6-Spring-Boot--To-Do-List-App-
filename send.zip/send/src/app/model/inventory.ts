export class inventory {
    inventoryId: number;
    productId: number;
    merchantId: number;

    productStatus: string
    productActualPrice: string
    productDiscountPrice: string
    productQuantity: string
}