import { Component, OnInit } from '@angular/core';


export interface Food {
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-returnpage',
  templateUrl: './returnpage.component.html',
  styleUrls: ['./returnpage.component.css']
})
export class ReturnpageComponent implements OnInit {
  router: any;

  constructor() { }

  ngOnInit() {
  }

  GoToRefund() {
    this.router.navigate(['/refund']);
  }

  

}
