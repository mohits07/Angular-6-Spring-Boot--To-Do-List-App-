import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReturngoodsComponent } from './returngoods.component';

describe('ReturngoodsComponent', () => {
  let component: ReturngoodsComponent;
  let fixture: ComponentFixture<ReturngoodsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReturngoodsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReturngoodsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
