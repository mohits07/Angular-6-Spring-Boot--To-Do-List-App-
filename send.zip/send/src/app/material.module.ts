import { NgModule } from '@angular/core';
import {  MatButtonModule, MatInputModule } from '@angular/material';

import { RefundComponent } from './refund/refund.component';
import {MatRadioModule} from '@angular/material/radio';
import { ReturnpageComponent } from './returnpage/returnpage.component';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatSelectModule} from '@angular/material/select';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
@NgModule({
  imports: [
    MatButtonModule,
    MatRadioModule,
    MatSelectModule,
    MatFormFieldModule,
    BrowserAnimationsModule,
    MatInputModule,
    
    
  ],
  exports:[
    MatButtonModule,
    MatRadioModule,
    MatSelectModule,
    MatFormFieldModule,
    BrowserAnimationsModule,
    MatInputModule
    
  ],
  declarations: [RefundComponent,ReturnpageComponent]
})
export class MaterialModule { }
