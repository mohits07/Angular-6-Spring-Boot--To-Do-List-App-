import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ReturngoodsComponent } from './returngoods/returngoods.component';
import { ReturnpageComponent } from './returnpage/returnpage.component';

import { RefundComponent } from './refund/refund.component';
import { ReturnmessageComponent } from './returnmessage/returnmessage.component';

const routes: Routes = [
  { path: '', redirectTo: '/return', pathMatch: 'full' },
  
  { path: 'refund', component : RefundComponent ,pathMatch: 'full'},
  { path: 'return', component : ReturngoodsComponent },
  { path: 'returnpage', component : ReturnpageComponent},
  { path: 'returnmessage', component : ReturnmessageComponent ,pathMatch: 'full'},
  { path: '**', redirectTo: '/return', pathMatch: 'full' }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
